﻿

namespace Bombones2025.Entidades
{
    public class Relleno
    {
        public int IdRelleno { get; set; }
        public string NombreRelleno { get; set; } = null!;
        public string Descripcion { get; set; } = null!;
    }
        
}
