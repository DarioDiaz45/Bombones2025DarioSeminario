﻿
namespace Bombones2025.Entidades
{
    public class TipoChocolate
    {
        public string NombreChocolate { get; set; } = null!;
        public int IdChocolate { get; set; }
        
        

    }
}
