﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bombones2025.Entidades
{
    public class FrutosSecos
    {
        public int IdFruto { get; set; }
        public string NombreFruto { get; set; } = null!;

      
        

    }
}
