﻿namespace Pais.Entidades
{
    public class Class1
    {

    }
}
